/* ============================================================
   Purgō Water — behaviour
   ============================================================ */

var REDUCED = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/* ---------- ambient water layer ---------- */
(function () {
  if (document.querySelector('.ambient')) return;

  var amb = document.createElement('div');
  amb.className = 'ambient';
  amb.setAttribute('aria-hidden', 'true');
  amb.innerHTML =
    '<div class="ambient-blob b1"></div>' +
    '<div class="ambient-blob b2"></div>' +
    '<div class="ambient-blob b3"></div>' +
    '<canvas class="caustics" width="220" height="140"></canvas>' +
    '<div class="ambient-grain"></div>';
  document.body.insertBefore(amb, document.body.firstChild);

  var bar = document.createElement('div');
  bar.className = 'scroll-progress';
  document.body.appendChild(bar);

  if (REDUCED) return;

  /* --- caustics ---
     Sum of a few sine waves at different angles, sampled per pixel on a
     tiny 220x140 buffer and stretched to fill the viewport. Cheap enough
     to run every other frame; the CSS blur hides the low resolution. */
  var cv = amb.querySelector('.caustics');
  var ctx = cv.getContext('2d', { alpha: true });
  var W = cv.width, H = cv.height;
  var img = ctx.createImageData(W, H);
  var t = 0, frame = 0, raf;

  function draw() {
    frame++;
    if (frame % 2 === 0) {
      t += 0.012;
      var d = img.data, i = 0;
      for (var y = 0; y < H; y++) {
        var fy = y / H;
        for (var x = 0; x < W; x++, i += 4) {
          var fx = x / W;
          var v =
            Math.sin((fx * 9.0) + t * 1.7) +
            Math.sin((fy * 7.0) - t * 1.2) +
            Math.sin((fx * 5.5 + fy * 6.5) + t * 2.1) +
            Math.sin(Math.sqrt((fx - .5) * (fx - .5) + (fy - .5) * (fy - .5)) * 22 - t * 2.6);

          /* v ranges roughly -4..4 — push the peaks so only the bright
             ridges show, which is what reads as caustic light */
          var n = (v + 4) / 8;
          var a = Math.pow(n, 7) * 255;

          d[i]     = 127;  /* accent rgb */
          d[i + 1] = 242;
          d[i + 2] = 212;
          d[i + 3] = a;
        }
      }
      ctx.putImageData(img, 0, 0);
    }
    raf = requestAnimationFrame(draw);
  }
  draw();

  /* pause when the tab is hidden */
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) { cancelAnimationFrame(raf); }
    else { raf = requestAnimationFrame(draw); }
  });
})();

/* ---------- scroll progress + parallax drift ---------- */
(function () {
  var bar = document.querySelector('.scroll-progress');
  var blobs = Array.prototype.slice.call(document.querySelectorAll('.ambient-blob'));
  var ticking = false;

  function onScroll() {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(function () {
      var max = document.documentElement.scrollHeight - window.innerHeight;
      var p = max > 0 ? window.scrollY / max : 0;

      if (bar) bar.style.transform = 'scaleX(' + p + ')';

      if (!REDUCED) {
        /* the water body drifts slower than the page — depth cue */
        blobs.forEach(function (b, i) {
          var rate = [0.10, -0.06, 0.14][i] || 0.1;
          b.style.translate = '0 ' + (window.scrollY * rate) + 'px';
        });
      }
      ticking = false;
    });
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
})();

/* ---------- word-mask headings ----------
   Wraps each word of a heading in a clipped span so it can rise into
   place. Skipped for headings containing markup we shouldn't touch. */
(function () {
  if (REDUCED) return;
  var heads = document.querySelectorAll('.hero h1, .page-head h1, .section-head h2, .cta-band h2');

  Array.prototype.forEach.call(heads, function (h) {
    if (h.dataset.split) return;
    var kids = Array.prototype.slice.call(h.childNodes);
    var out = '';
    var ok = true;

    kids.forEach(function (n) {
      if (n.nodeType === 3) {
        out += n.nodeValue.split(/(\s+)/).map(function (w) {
          if (!w.trim()) return w;
          return '<span class="w"><span class="wi">' + w + '</span></span>';
        }).join('');
      } else if (n.nodeType === 1 && n.tagName === 'EM') {
        out += '<span class="w"><span class="wi"><em>' + n.innerHTML + '</em></span></span>';
      } else {
        ok = false;
      }
    });

    if (!ok) return;
    h.innerHTML = out;
    h.dataset.split = '1';

    /* stagger each word */
    Array.prototype.forEach.call(h.querySelectorAll('.wi'), function (w, i) {
      w.style.transitionDelay = (i * 0.045) + 's';
    });

    h.classList.add('reveal-head');
  });
})();

/* ---------- mobile nav + dropdowns ---------- */
(function () {
  var header = document.querySelector('.site-header');
  var burger = document.querySelector('.hamburger');
  if (burger && header) {
    burger.addEventListener('click', function () {
      var open = header.getAttribute('data-menu') === 'open';
      header.setAttribute('data-menu', open ? 'closed' : 'open');
      burger.setAttribute('aria-expanded', String(!open));
    });
  }

  document.querySelectorAll('.nav-drop').forEach(function (drop) {
    var btn = drop.querySelector('button');
    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      var open = drop.getAttribute('data-open') === 'true';
      document.querySelectorAll('.nav-drop').forEach(function (d) {
        d.setAttribute('data-open', 'false');
      });
      drop.setAttribute('data-open', String(!open));
      btn.setAttribute('aria-expanded', String(!open));
    });
  });

  document.addEventListener('click', function () {
    document.querySelectorAll('.nav-drop').forEach(function (d) {
      d.setAttribute('data-open', 'false');
    });
  });
})();

/* ---------- scroll reveal ---------- */
(function () {
  var sel = '.reveal, .reveal-head';
  var items = document.querySelectorAll(sel);

  if (!items.length || !('IntersectionObserver' in window)) {
    document.querySelectorAll(sel).forEach(function (el) { el.classList.add('in'); });
    return;
  }

  window.__pwReveal = new IntersectionObserver(function (entries, obs) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        entry.target.classList.add('in');
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -60px' });

  items.forEach(function (el) { window.__pwReveal.observe(el); });
})();

/* ---------- signature: "what's in your tap" lookup ----------
   These are the general patterns we see region to region.
   They are starting points for the conversation, not a substitute
   for the on-site test every install begins with.
------------------------------------------------------------- */
var TAP_DATA = {
  nyc: {
    label: 'New York City',
    hardness: '1\u20132',
    hardnessNote: 'grains per gallon \u2014 soft',
    disinfectant: 'chlorine',
    disinfectantNote: 'plus orthophosphate',
    age: '100+ yrs',
    ageNote: 'typical main age',
    findings: ['chlorine taste & odor', 'sediment from old mains', 'lead risk at the building', 'rooftop tank carryover'],
    story: 'The reservoir water arriving in the five boroughs is genuinely good and genuinely soft. What changes it is the last hundred feet \u2014 century-old cast iron mains, building risers, solder joints in pre-1987 plumbing, and rooftop tanks. So in the city we rarely soften. We filter for what the building adds.',
    rec: 'Whole-home carbon + sediment for the taste and grit, and a reverse osmosis unit at the kitchen tap if your building predates 1987.'
  },
  westchester: {
    label: 'Westchester',
    hardness: '1\u201312',
    hardnessNote: 'grains per gallon \u2014 varies widely',
    disinfectant: 'chlorine',
    disinfectantNote: 'well water: none',
    age: 'mixed',
    ageNote: 'municipal & private well',
    findings: ['hardness north of I-287', 'iron & manganese staining', 'wells with no disinfection', 'seasonal turbidity'],
    story: 'Westchester is really two water stories. Yonkers, Mount Vernon and the river towns drink much the same soft aqueduct water as the city. Head north toward Somers, North Salem or Lewisboro and you are often on a private well drawing through bedrock \u2014 harder, higher in iron, and untreated.',
    rec: 'South county: carbon filtration and drinking water. North county: a full test first, then usually a softener plus iron removal and UV.'
  },
  nj: {
    label: 'New Jersey',
    hardness: '5\u201315',
    hardnessNote: 'grains per gallon \u2014 moderate to hard',
    disinfectant: 'chlorine',
    disinfectantNote: 'or chloramine',
    age: 'varies',
    ageNote: 'by utility district',
    findings: ['scale on fixtures and heaters', 'PFAS in some districts', 'chloramine taste', 'aquifer hardness'],
    story: 'New Jersey water depends heavily on which utility serves your block, and neighbouring towns can differ sharply. Hardness is common enough that most homes see scale on the kettle and the shower door. The state has also been among the most active in the country on PFAS limits, which is why we default to including carbon in Jersey builds.',
    rec: 'Softener plus carbon as the base, and reverse osmosis for drinking. We pull your utility\u2019s current water quality report before quoting.'
  },
  ct: {
    label: 'Connecticut',
    hardness: '7\u201320',
    hardnessNote: 'grains per gallon \u2014 hard',
    disinfectant: 'none',
    disinfectantNote: 'on private wells',
    age: 'bedrock',
    ageNote: 'typical well type',
    findings: ['hard water and scale', 'iron and manganese', 'sulfur odor', 'no disinfection on wells'],
    story: 'A large share of Connecticut homes draw from private bedrock wells, which means no utility is treating anything before it reaches you. What comes up is usually hard, often carries iron or manganese, and sometimes brings the rotten-egg smell of hydrogen sulfide. It is also the region where a proper lab test matters most, because two wells on the same road can read completely differently.',
    rec: 'A dual-tank well build: softening plus iron and sulfur removal, with UV for bacterial protection. Always after a full lab panel.'
  }
};

(function () {
  var picker = document.querySelector('[data-picker]');
  var out = document.querySelector('[data-readout]');
  if (!picker || !out) return;

  function render(key, animate) {
    var d = TAP_DATA[key];
    if (!d) return;

    out.innerHTML =
      '<dl class="metrics">' +
        '<div class="metric"><dt>hardness</dt><dd>' + d.hardness + '<small>' + d.hardnessNote + '</small></dd></div>' +
        '<div class="metric"><dt>disinfectant</dt><dd>' + d.disinfectant + '<small>' + d.disinfectantNote + '</small></dd></div>' +
        '<div class="metric"><dt>delivery</dt><dd>' + d.age + '<small>' + d.ageNote + '</small></dd></div>' +
      '</dl>' +
      '<span class="report-label">what we usually find</span>' +
      '<ul class="tag-list">' + d.findings.map(function (f) { return '<li>' + f + '</li>'; }).join('') + '</ul>' +
      '<p>' + d.story + '</p>' +
      '<div class="rec">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M9 18h6M10 22h4M12 2a7 7 0 0 0-4 12.7V17h8v-2.3A7 7 0 0 0 12 2z"/></svg>' +
        '<span><strong>Where we usually start:</strong> ' + d.rec + '</span>' +
      '</div>';

    if (animate && !REDUCED) {
      out.animate(
        [{ opacity: 0, transform: 'translateY(8px)' }, { opacity: 1, transform: 'none' }],
        { duration: 450, easing: 'cubic-bezier(.16,1,.3,1)' }
      );
    }
  }

  picker.addEventListener('click', function (e) {
    var btn = e.target.closest('button[data-region]');
    if (!btn) return;
    picker.querySelectorAll('button').forEach(function (b) { b.setAttribute('aria-pressed', 'false'); });
    btn.setAttribute('aria-pressed', 'true');
    render(btn.getAttribute('data-region'), true);
  });

  render('nyc', false);
})();

/* ---------- quote form ---------- */
(function () {
  var form = document.querySelector('[data-quote-form]');
  if (!form) return;
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var ok = form.querySelector('.form-ok');
    if (ok) {
      ok.style.display = 'block';
      ok.setAttribute('role', 'status');
      ok.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    form.reset();
  });
})();

/* ---------- year ---------- */
document.querySelectorAll('[data-year]').forEach(function (el) {
  el.textContent = new Date().getFullYear();
});
