# Deploying Purgō Water to GitHub Pages

Static site, no build step. Push it and it's live.

---

## 1. SSH key (one time, per machine)

GitHub stopped accepting password auth over HTTPS, so you'd otherwise be
managing personal access tokens. SSH keys are simpler and don't expire.

```bash
# check whether you already have one
ls -al ~/.ssh/id_ed25519.pub

# if not, make one (press Enter through the prompts; a passphrase is optional but wise)
ssh-keygen -t ed25519 -C "you@purgowater.com"

# load it into the agent
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_ed25519

# copy the PUBLIC key — this is the one that's safe to share
cat ~/.ssh/id_ed25519.pub
```

Paste that into GitHub under **Settings → SSH and GPG keys → New SSH key**.
Then confirm it works:

```bash
ssh -T git@github.com
# expect: "Hi <username>! You've successfully authenticated..."
```

Never share `~/.ssh/id_ed25519` (no `.pub`). That's the private half.

---

## 2. Push the site

Create an empty repo on GitHub first — no README, no .gitignore, since this
folder already has both.

```bash
cd purgo-water

git init -b main
git add .
git commit -m "Purgō Water site"

# SSH remote (recommended)
git remote add origin git@github.com:USERNAME/purgo-water.git

git push -u origin main
```

### HTTPS remote instead

If you'd rather not deal with keys, use the HTTPS URL. You'll be asked for a
**personal access token** as the password, not your account password —
generate one at Settings → Developer settings → Personal access tokens.

```bash
git remote add origin https://github.com/USERNAME/purgo-water.git
```

Switching an existing repo between the two:

```bash
git remote set-url origin git@github.com:USERNAME/purgo-water.git      # to SSH
git remote set-url origin https://github.com/USERNAME/purgo-water.git  # to HTTPS
git remote -v                                                          # confirm
```

---

## 3. Turn Pages on

Repo → **Settings → Pages → Build and deployment → Source: GitHub Actions**.

The included `.github/workflows/pages.yml` then publishes on every push to
`main`. Watch it under the Actions tab; the first run takes about a minute.

Your site will be at `https://USERNAME.github.io/purgo-water/`.

> **Note on the subpath.** All links in the site are relative
> (`href="whole-home.html"`, `assets/style.css`), so they work fine under a
> subpath. But if you name the repo `USERNAME.github.io` instead, the site
> serves from the domain root, which is tidier.

---

## 4. HTTPS

**You don't configure anything.** GitHub provisions a Let's Encrypt
certificate automatically for both `*.github.io` and custom domains, and
renews it. There's no certbot, no nginx, no cert files in the repo.

### With the custom domain

The `CNAME` file in this folder currently reads `purgowater.com` — change it
to your real domain, or delete it if you're staying on the `github.io` URL.

At your registrar, add these DNS records:

| Type  | Name  | Value                                   |
|-------|-------|-----------------------------------------|
| A     | `@`   | `185.199.108.153`                       |
| A     | `@`   | `185.199.109.153`                       |
| A     | `@`   | `185.199.110.153`                       |
| A     | `@`   | `185.199.111.153`                       |
| CNAME | `www` | `USERNAME.github.io.`                   |

Then in **Settings → Pages**, enter the domain and wait for the DNS check to
pass. Once it does, tick **Enforce HTTPS**.

The certificate can take up to an hour after DNS propagates. Until then
you'll see a warning on the Pages settings screen — that's expected, not a
misconfiguration. Don't tick Enforce HTTPS before the check passes or the
site will briefly 404.

---

## 5. Updating the site later

```bash
git add .
git commit -m "what changed"
git push
```

Live in about a minute.

---

## Files in here that are infrastructure, not content

| File | Why |
|---|---|
| `.github/workflows/pages.yml` | Builds and deploys on push |
| `CNAME` | Tells Pages which custom domain to serve |
| `.nojekyll` | Stops Jekyll from processing the folder — harmless here, but it prevents Jekyll ignoring any future file or folder starting with `_` |
| `.gitignore` | Keeps OS junk out of the repo |
